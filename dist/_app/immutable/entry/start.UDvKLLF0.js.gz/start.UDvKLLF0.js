import{a as t}from"../chunks/entry.i6kiaLbd.js";export{t as start};
