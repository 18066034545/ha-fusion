import{a as t}from"../chunks/entry.ssoPwoHB.js";export{t as start};
