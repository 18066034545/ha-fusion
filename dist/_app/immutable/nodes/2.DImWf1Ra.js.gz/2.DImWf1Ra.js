import{D as m}from"../chunks/2.PYNQplxn.js";export{m as component};
