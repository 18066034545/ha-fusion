import{D as m}from"../chunks/2.C41V4jFO.js";export{m as component};
