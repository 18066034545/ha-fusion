import{D as m}from"../chunks/2.DxYEmZCZ.js";export{m as component};
