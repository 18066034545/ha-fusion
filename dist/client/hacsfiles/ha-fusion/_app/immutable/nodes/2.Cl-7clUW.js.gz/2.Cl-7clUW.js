import{D as m}from"../chunks/2.dCG7GHcU.js";export{m as component};
