import{a as t}from"../chunks/entry.Cf6q3Gri.js";export{t as start};
